// src/pages/Applicants.jsx - 完整版本 + 调试信息
import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { db } from "../lib/firebase";
import { ref, onValue, update, get } from "firebase/database";
import { useAuthState } from "../lib/useAuthState";
import { useRole } from "../lib/useRole";

export default function Applicants() {
  // 兼容 /employer/jobs/:jobId/applicants 和 /employer/jobs/:id/applicants
  const { jobId, id } = useParams();
  const effectiveId = jobId || id;

  const { user, loading: authLoading } = useAuthState();
  const { role, loaded: roleLoaded } = useRole();

  const [job, setJob] = useState(null);
  const [apps, setApps] = useState([]);
  const [loadingJob, setLoadingJob] = useState(true);
  const [loadingApps, setLoadingApps] = useState(true);
  const [updatingId, setUpdatingId] = useState(null); // 正在更新状态的申请人

  // 评价弹窗状态
  const [ratingState, setRatingState] = useState({
    open: false,
    app: null, // 整个 application 对象
    score: 5,
    late: false,
    saving: false,
  });



  /* ---------------- 读取职位信息 ---------------- */
  useEffect(() => {
    if (!effectiveId) {
      setLoadingJob(false);
      return;
    }

    const jobRef = ref(db, "jobs/" + effectiveId);
    const unsub = onValue(
      jobRef,
      (snap) => {
        if (snap.exists()) {
          setJob(snap.val());
        }
        setLoadingJob(false);
      },
      () => setLoadingJob(false)
    );
    return () => unsub();
  }, [effectiveId]);

  /* ---------------- 读取申请列表 ---------------- */
  useEffect(() => {
    if (!effectiveId) {
      setApps([]);
      setLoadingApps(false);
      return;
    }

    const appRef = ref(db, "applications/" + effectiveId);
    const unsub = onValue(
      appRef,
      (snap) => {
        if (!snap.exists()) {
          setApps([]);
          setLoadingApps(false);
          return;
        }
        const list = [];
        snap.forEach((a) => list.push({ id: a.key, ...a.val() }));
        // 最新在上
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setApps(list);
        setLoadingApps(false);
      },
      () => {
        setApps([]);
        setLoadingApps(false);
      }
    );
    return () => unsub();
  }, [effectiveId]);

  /* ---------------- 权限 & Loading ---------------- */
  if (authLoading || !roleLoaded || loadingJob) {
    return (
      <div className="container">
        <div className="card">
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  if (!user || role !== "employer") {
    return (
      <div className="container">
        <div className="card">
          <h2>无权限访问</h2>
          <p>只有雇主才能查看申请人列表。</p>
          <Link className="btn" to="/login" style={{ marginTop: 12 }}>
            去登录
          </Link>
        </div>
      </div>
    );
  }

  /* ---------------- 辅助函数：状态文案 / 样式 ---------------- */
  const statusLabel = (status) => {
    switch (status) {
      case "shortlisted":
        return "✅ 已入围";
      case "rejected":
        return "❌ 未被录用";
      case "hired":
        return "🎉 已录用";
      default:
        return "📩 已申请";
    }
  };

  const statusPillClass = (status) => {
    switch (status) {
      case "shortlisted":
        return "pill success";
      case "rejected":
        return "pill danger";
      case "hired":
        return "pill success";
      default:
        return "pill info";
    }
  };

  /* ---------------- 修改申请状态（入围 / 拒绝）---------------- */
  async function handleChangeStatus(appId, newStatus) {
    if (!effectiveId || !appId) return;
    setUpdatingId(appId);
    try {
      const appRef = ref(db, `applications/${effectiveId}/${appId}`);
      await update(appRef, { status: newStatus });

      // 本地也先更新一次，UI 更快
      setApps((prev) =>
        prev.map((a) =>
          a.id === appId ? { ...a, status: newStatus } : a
        )
      );
    } catch (err) {
      console.error("Failed to update status", err);
      alert("更新状态失败，请稍后再试。");
    } finally {
      setUpdatingId(null);
    }
  }

  /* ---------------- 打开"录用 + 评价"弹窗 ---------------- */
  function openRatingModal(appId) {
    const app = apps.find((a) => a.id === appId);
    if (!app) return;
    setRatingState({
      open: true,
      app,
      score: 5,
      late: false,
      saving: false,
    });
  }

  function closeRatingModal() {
    if (ratingState.saving) return;
    setRatingState({
      open: false,
      app: null,
      score: 5,
      late: false,
      saving: false,
    });
  }

  /* ---------------- 提交评价 + 标记为已录用 ---------------- */
  async function handleSubmitRating(e) {
    e?.preventDefault();
    if (!ratingState.app || !effectiveId) return;

    const app = ratingState.app;
    const score = ratingState.score;
    const late = ratingState.late;

    setRatingState((prev) => ({ ...prev, saving: true }));

    try {
      // 1）更新 application：状态 + 这次评价
      const appRef = ref(db, `applications/${effectiveId}/${app.id}`);
      await update(appRef, {
        status: "hired",
        ratingGiven: score,
        late: late,
        ratedAt: Date.now(),
      });

      // 2）更新求职者 profile 的评分 & 出勤率
      if (app.userId) {
        const profileRef = ref(db, "profiles/" + app.userId);
        const snap = await get(profileRef);
        const val = snap.val() || {};

        // 评分
        const prevRating =
          typeof val.ratingScore === "number"
            ? val.ratingScore
            : parseFloat(val.ratingScore) || 5.0;
        const prevRatingCount =
          typeof val.ratingCount === "number"
            ? val.ratingCount
            : parseInt(val.ratingCount) || 0;

        const newRatingCount = prevRatingCount + 1;
        const newRatingScore =
          (prevRating * prevRatingCount + score) / newRatingCount;

        // 出勤率：假设 late=false 表示"这次准时 / 正常出勤"
        const prevAttendRate =
          typeof val.attendanceRate === "number"
            ? val.attendanceRate
            : parseFloat(val.attendanceRate) || 100;
        const prevAttendCount =
          typeof val.attendanceCount === "number"
            ? val.attendanceCount
            : parseInt(val.attendanceCount) || 0;

        const prevOnTimeTotal =
          (prevAttendRate * prevAttendCount) / 100; // 准时次数
        const newAttendCount = prevAttendCount + 1;
        const newOnTimeTotal = prevOnTimeTotal + (late ? 0 : 1);
        const newAttendRate =
          newAttendCount > 0
            ? (newOnTimeTotal / newAttendCount) * 100
            : 100;

        await update(profileRef, {
          ratingScore: newRatingScore,
          ratingCount: newRatingCount,
          attendanceRate: newAttendRate,
          attendanceCount: newAttendCount,
        });
      }

      // 3）本地更新列表
      setApps((prev) =>
        prev.map((a) =>
          a.id === app.id
            ? {
                ...a,
                status: "hired",
                ratingGiven: score,
                late: late,
              }
            : a
        )
      );

      closeRatingModal();
    } catch (err) {
      console.error("Failed to submit rating", err);
      alert("提交评价失败，请稍后再试。");
      setRatingState((prev) => ({ ...prev, saving: false }));
    }
  }

  const total = apps.length;
  const hiredCount = apps.filter((a) => a.status === "hired").length;
  const shortlistedCount = apps.filter(
    (a) => a.status === "shortlisted"
  ).length;
  const rejectedCount = apps.filter(
    (a) => a.status === "rejected"
  ).length;

  return (
    <div className="container">
      {/* 顶部：职位信息 + 汇总 */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: 16,
            alignItems: "flex-start",
            flexWrap: "wrap",
          }}
        >
          <div>
            <div
              style={{
                fontSize: 12,
                color: "var(--muted)",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                marginBottom: 4,
              }}
            >
              职位申请人
            </div>
            <h2 style={{ margin: 0, fontSize: 22 }}>
              {job?.title || "职位名称"}
            </h2>
            <p
              style={{
                margin: "4px 0 0",
                fontSize: 13,
                color: "var(--muted)",
              }}
            >
              {job?.companyName || "公司名称"} ·{" "}
              {job?.location || "工作地点未填写"}
            </p>
          </div>

          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-end",
              gap: 8,
              minWidth: 200,
            }}
          >
            <div className="pill info">
              <span className="dot" />
              <span style={{ fontSize: 13 }}>
                共 {total} 位申请人
              </span>
            </div>

            <div
              style={{
                display: "flex",
                gap: 8,
                flexWrap: "wrap",
                justifyContent: "flex-end",
              }}
            >
              {hiredCount > 0 && (
                <span className="pill success" style={{ fontSize: 12 }}>
                  已录用 {hiredCount}
                </span>
              )}
              {shortlistedCount > 0 && (
                <span className="pill" style={{ fontSize: 12 }}>
                  入围 {shortlistedCount}
                </span>
              )}
              {rejectedCount > 0 && (
                <span className="pill danger" style={{ fontSize: 12 }}>
                  已拒绝 {rejectedCount}
                </span>
              )}
            </div>

            <div
              style={{
                display: "flex",
                gap: 8,
                flexWrap: "wrap",
                justifyContent: "flex-end",
                marginTop: 4,
              }}
            >
              <Link
                to={`/jobs/${effectiveId}`}
                className="btn"
                style={{
                  textDecoration: "none",
                  padding: "8px 12px",
                  fontSize: 13,
                }}
              >
                查看职位详情
              </Link>
            </div>
          </div>
        </div>


      </div>

      {/* 下方：申请人列表 */}
      <div className="card">
        {loadingApps && <p>加载中...</p>}

        {!loadingApps && total === 0 && (
          <div
            className="empty"
            style={{ marginTop: 8, marginBottom: 8 }}
          >
            暂时还没有人申请这个职位。可以把职位分享给更多人看看。
          </div>
        )}

        {!loadingApps &&
          total > 0 &&
          apps.map((app) => {
            const appliedAt = app.createdAt
              ? new Date(app.createdAt).toLocaleString("zh-CN", {
                  year: "numeric",
                  month: "short",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })
              : "";

            const waNumber = app.phone
              ? app.phone.replace(/\D/g, "")
              : "";
            const waLink =
              waNumber.length >= 9
                ? `https://wa.me/6${waNumber}?text=${encodeURIComponent(
                    `你好，我是 ${job?.companyName || "老板"}，在 FastJob 收到你投递 [${
                      job?.title || ""
                    }] 的申请。`
                  )}`
                : null;

            return (
              <div
                key={app.id}
                style={{
                  borderTop: "1px solid var(--border-soft)",
                  padding: "12px 0",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: 16,
                    alignItems: "flex-start",
                    flexWrap: "wrap",
                  }}
                >
                  {/* 左：基本信息 + 备注 */}
                  <div>
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 8,
                        marginBottom: 4,
                        flexWrap: "wrap",
                      }}
                    >
                      <h3
                        style={{
                          margin: 0,
                          fontSize: 16,
                        }}
                      >
                        {app.name || "未填写姓名"}
                      </h3>

                      <span
                        className={statusPillClass(app.status)}
                        style={{ fontSize: 12 }}
                      >
                        {statusLabel(app.status)}
                      </span>
                    </div>

                    <p
                      style={{
                        margin: "2px 0 0",
                        fontSize: 14,
                        color: "var(--muted)",
                      }}
                    >
                      手机：{app.phone || "未填写"}
                    </p>

                    {app.email && (
                      <p
                        style={{
                          margin: "2px 0 0",
                          fontSize: 13,
                          color: "var(--muted)",
                        }}
                      >
                        邮箱：{app.email}
                      </p>
                    )}

                    {appliedAt && (
                      <p
                        style={{
                          margin: "6px 0 0",
                          fontSize: 12,
                          color: "var(--muted)",
                        }}
                      >
                        投递时间：{appliedAt}
                      </p>
                    )}

                    {app.ratingGiven && (
                      <p
                        style={{
                          margin: "4px 0 0",
                          fontSize: 12,
                          color: "var(--muted)",
                        }}
                      >
                        本次评分：{app.ratingGiven.toFixed(1)} 分
                        {app.late ? "（有迟到/缺席）" : "（准时）"}
                      </p>
                    )}

                    {app.resumeLink && (
                      <p
                        style={{
                          margin: "6px 0 0",
                          fontSize: 13,
                        }}
                      >
                        <a
                          href={app.resumeLink}
                          target="_blank"
                          rel="noreferrer"
                          style={{ color: "var(--primary)" }}
                        >
                          打开简历 / 作品集
                        </a>
                      </p>
                    )}
                  </div>

                  {/* 右：操作按钮 */}
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: 8,
                      alignItems: "flex-end",
                      minWidth: 180,
                    }}
                  >
                    {waLink && (
                      <a
                        href={waLink}
                        target="_blank"
                        rel="noreferrer"
                        className="btn"
                        style={{
                          padding: "8px 14px",
                          fontSize: 13,
                          textDecoration: "none",
                        }}
                      >
                        ✅ WhatsApp 联系
                      </a>
                    )}

                    {/* 状态按钮组 */}
                    <button
                      type="button"
                      onClick={() =>
                        handleChangeStatus(app.id, "shortlisted")
                      }
                      disabled={updatingId === app.id}
                      className="btn-ghost"
                      style={{
                        fontSize: 12,
                        padding: "6px 10px",
                        borderRadius: 999,
                      }}
                    >
                      入围
                    </button>

                    <button
                      type="button"
                      onClick={() => openRatingModal(app.id)}
                      className="btn-ghost"
                      style={{
                        fontSize: 12,
                        padding: "6px 10px",
                        borderRadius: 999,
                      }}
                    >
                      录用 + 评价
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        handleChangeStatus(app.id, "rejected")
                      }
                      disabled={updatingId === app.id}
                      className="btn-ghost"
                      style={{
                        fontSize: 12,
                        padding: "6px 10px",
                        borderRadius: 999,
                      }}
                    >
                      拒绝
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
      </div>

      {/* 评价弹窗 */}
      {ratingState.open && ratingState.app && (
        <div
          onClick={closeRatingModal}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15,23,42,0.7)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 50,
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "100%",
              maxWidth: 420,
              borderRadius: 20,
              background: "#020617",
              border: "1px solid var(--border)",
              padding: 18,
              boxShadow: "0 24px 60px rgba(15,23,42,0.8)",
            }}
          >
            <h3 style={{ margin: "0 0 8px", fontSize: 18 }}>
              完成工作评价
            </h3>
            <p
              style={{
                margin: "0 0 10px",
                fontSize: 13,
                color: "var(--muted)",
              }}
            >
              你正在评价：{ratingState.app.name || "未填写姓名"}
              <br />
              这次工作结束后，请按表现给一个评分，并标记是否有迟到 /
              缺席。
            </p>

            {/* 评分选择 */}
            <div style={{ marginBottom: 10 }}>
              <div
                style={{
                  fontSize: 13,
                  marginBottom: 6,
                }}
              >
                评分（1–5 分，5 分为表现非常好）
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                {[1, 2, 3, 4, 5].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() =>
                      setRatingState((prev) => ({
                        ...prev,
                        score: s,
                      }))
                    }
                    style={{
                      flex: 1,
                      padding: "6px 0",
                      borderRadius: 999,
                      border:
                        ratingState.score === s
                          ? "none"
                          : "1px solid var(--border)",
                      background:
                        ratingState.score === s
                          ? "var(--primary)"
                          : "transparent",
                      color:
                        ratingState.score === s
                          ? "#fff"
                          : "var(--muted)",
                      fontSize: 14,
                      cursor: "pointer",
                    }}
                  >
                    {s} 分
                  </button>
                ))}
              </div>
            </div>

            {/* 出勤标记 */}
            <div
              style={{
                marginBottom: 12,
                display: "flex",
                alignItems: "center",
                gap: 8,
                fontSize: 13,
              }}
            >
              <input
                id="rating-late"
                type="checkbox"
                checked={ratingState.late}
                onChange={(e) =>
                  setRatingState((prev) => ({
                    ...prev,
                    late: e.target.checked,
                  }))
                }
              />
              <label htmlFor="rating-late">
                这次有迟到 / 缺席（勾选会拉低出勤率）
              </label>
            </div>

            {/* 按钮 */}
            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                gap: 8,
              }}
            >
              <button
                type="button"
                onClick={closeRatingModal}
                className="btn-ghost"
                disabled={ratingState.saving}
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleSubmitRating}
                className="btn"
                disabled={ratingState.saving}
              >
                {ratingState.saving
                  ? "提交中…"
                  : "提交评价并标记为已录用"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}